Da Capo
========

Simple PHP database wrapper

Copyright [Christos Pontikis][copyright]
[copyright]: http://www.pontikis.net

License [MIT][mit]
[mit]: https://raw.github.com/pontikis/dacapo/master/MIT_LICENSE


Release 0.9.0 (03 May 2014)
---------------------------
* select, update, insert, delete
* transactions
* utility functions (qstr, lower, limit)
