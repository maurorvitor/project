dacapo
======

Simple PHP database wrapper

Copyright [Christos Pontikis][copyright]
[copyright]: http://www.pontikis.net

License [MIT][mit]
[mit]: https://raw.github.com/pontikis/dacapo/master/MIT_LICENSE

 * Supported RDMBS: MySQLi, POSTGRESQL
 * For MYSQLi SELECT prepared statements, mysqlnd is required
 * Persistent database connection NOT supported.
 * BLOB columns NOT supported
 * avoid boolean columns, use integer instead (1,0)

Documenation
------------

Coming soon